import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import date
import matplotlib.pyplot as plt

# ---------------- DATABASE ----------------
conn = sqlite3.connect(r"C:\Users\Chan Kok Han\Desktop\Semester 6 to 10\money management\finance.db")
cur = conn.cursor()

cur.execute("""CREATE TABLE IF NOT EXISTS income(
id INTEGER PRIMARY KEY AUTOINCREMENT,
source TEXT,
amount REAL,
date TEXT)""")

cur.execute("""CREATE TABLE IF NOT EXISTS expense(
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT,
amount REAL,
date TEXT)""")

conn.commit()

# ---------------- DASHBOARD ----------------
def dashboard():
    dash = tk.Tk()
    dash.title("Money Management System")
    dash.geometry("1000x650")

    style = ttk.Style()
    style.theme_use("clam")

    today = date.today().isoformat()

    # ---------- SUMMARY ----------
    def update_summary():
        cur.execute("SELECT SUM(amount) FROM income")
        inc = cur.fetchone()[0] or 0
        cur.execute("SELECT SUM(amount) FROM expense")
        exp = cur.fetchone()[0] or 0
        bal = inc - exp
        lbl_income.config(text=f"₹ {inc}")
        lbl_expense.config(text=f"₹ {exp}")
        lbl_balance.config(text=f"₹ {bal}")

    # ---------- CRUD ----------
    def add_income():
        if not amt.get() or not src.get():
            messagebox.showerror("Error", "Enter source and amount")
            return
        try:
            amount = float(amt.get())
        except:
            messagebox.showerror("Error", "Invalid amount")
            return
        cur.execute("INSERT INTO income VALUES(NULL,?,?,?)",
                    (src.get(), amount, today))
        conn.commit()
        refresh()

    def add_expense():
        if not amt.get() or not src.get():
            messagebox.showerror("Error", "Enter title and amount")
            return
        try:
            amount = float(amt.get())
        except:
            messagebox.showerror("Error", "Invalid amount")
            return
        cur.execute("INSERT INTO expense VALUES(NULL,?,?,?)",
                    (src.get(), amount, today))
        conn.commit()
        refresh()

    def delete_transaction():
        item = tree.selection()
        if not item:
            return
        row_id = tree.item(item)["values"][0]
        ttype = tree.item(item)["values"][2]

        if ttype == "Income":
            cur.execute("DELETE FROM income WHERE id=?", (row_id,))
        else:
            cur.execute("DELETE FROM expense WHERE id=?", (row_id,))
        conn.commit()
        refresh()

    def edit_transaction():
        item = tree.selection()
        if not item:
            return
        try:
            new_amount = float(edit_amt.get())
        except:
            messagebox.showerror("Error", "Enter a valid amount")
            return

        row_id = tree.item(item)["values"][0]
        ttype = tree.item(item)["values"][2]

        if ttype == "Income":
            cur.execute("UPDATE income SET amount=? WHERE id=?",
                        (new_amount, row_id))
        else:
            cur.execute("UPDATE expense SET amount=? WHERE id=?",
                        (new_amount, row_id))
        conn.commit()
        refresh()

    # ---------- TABLE ----------
    def refresh():
        for i in tree.get_children():
            tree.delete(i)

        cur.execute("SELECT id, source, amount, date FROM income")
        for r in cur.fetchall():
            tree.insert("", "end",
                        values=(r[0], r[3], "Income", r[1], r[2]))

        cur.execute("SELECT id, title, amount, date FROM expense")
        for r in cur.fetchall():
            tree.insert("", "end",
                        values=(r[0], r[3], "Expense", r[1], r[2]))

        update_summary()

    # ---------- SEARCH ----------
    def search():
        key = search_entry.get().lower()
        for i in tree.get_children():
            tree.delete(i)

        cur.execute("SELECT id, source, amount, date FROM income")
        for r in cur.fetchall():
            if key in r[1].lower():
                tree.insert("", "end",
                            values=(r[0], r[3], "Income", r[1], r[2]))

        cur.execute("SELECT id, title, amount, date FROM expense")
        for r in cur.fetchall():
            if key in r[1].lower():
                tree.insert("", "end",
                            values=(r[0], r[3], "Expense", r[1], r[2]))

    # ---------- CHART ----------
    def chart():
        # Get monthly income
        cur.execute("""
            SELECT substr(date,1,7) AS month, SUM(amount)
            FROM income
            GROUP BY month
        """)
        inc = dict(cur.fetchall())

        # Get monthly expense
        cur.execute("""
            SELECT substr(date,1,7) AS month, SUM(amount)
            FROM expense
            GROUP BY month
        """)
        exp = dict(cur.fetchall())

        # All months
        months = sorted(set(inc) | set(exp))

        income_vals = [inc.get(m, 0) for m in months]
        expense_vals = [exp.get(m, 0) for m in months]
        balance_vals = [income_vals[i] - expense_vals[i] for i in range(len(months))]

        x = range(len(months))

        plt.figure(figsize=(10, 5))

        # Bars
        plt.bar(x, income_vals, width=0.4, label="Income", color="green")
        plt.bar(x, expense_vals, width=0.4, label="Expense",
                bottom=0, color="red", alpha=0.7)

        # Balance line
        plt.plot(x, balance_vals, marker="o",
                color="blue", linewidth=2, label="Balance")

        plt.xticks(x, months, rotation=45)
        plt.xlabel("Month")
        plt.ylabel("Amount")
        plt.title("Monthly Income, Expense & Balance")
        plt.legend()
        plt.tight_layout()
        plt.show()


    # ---------- SUMMARY CARDS ----------
    top = ttk.Frame(dash)
    top.pack(fill="x", pady=10)

    lbl_income = ttk.Label(top, text="₹ 0", font=("Segoe UI", 14, "bold"))
    lbl_income.pack(side="left", padx=50)
    ttk.Label(top, text="Total Income").pack(side="left")

    lbl_expense = ttk.Label(top, text="₹ 0", font=("Segoe UI", 14, "bold"))
    lbl_expense.pack(side="left", padx=50)
    ttk.Label(top, text="Total Expense").pack(side="left")

    lbl_balance = ttk.Label(top, text="₹ 0", font=("Segoe UI", 14, "bold"))
    lbl_balance.pack(side="left", padx=50)
    ttk.Label(top, text="Balance").pack(side="left")

    # ---------- INPUT ----------
    mid = ttk.Frame(dash)
    mid.pack(pady=10)

    src = ttk.Entry(mid)
    src.grid(row=0, column=0)
    src.insert(0, "Title / Source")

    amt = ttk.Entry(mid)
    amt.grid(row=0, column=1)
    amt.insert(0, "Amount")

    ttk.Button(mid, text="Add Income", command=add_income).grid(row=0, column=2)
    ttk.Button(mid, text="Add Expense", command=add_expense).grid(row=0, column=3)

    # ---------- SEARCH ----------
    search_entry = ttk.Entry(dash)
    search_entry.pack()
    search_entry.insert(0, "Search...")
    ttk.Button(dash, text="Search", command=search).pack()

    # ---------- TABLE ----------
    columns = ("ID", "Date", "Type", "Title", "Amount")
    tree = ttk.Treeview(dash, columns=columns, show="headings", height=12)

    for c in columns[1:]:
        tree.heading(c, text=c)

    tree.column("ID", width=0, stretch=False)
    tree.pack(fill="both", expand=True)

    # ---------- EDIT / DELETE ----------
    edit_amt = ttk.Entry(dash)
    edit_amt.pack()
    edit_amt.insert(0, "New Amount")

    btns = ttk.Frame(dash)
    btns.pack(pady=5)

    ttk.Button(btns, text="Edit", command=edit_transaction).pack(side="left", padx=5)
    ttk.Button(btns, text="Delete", command=delete_transaction).pack(side="left", padx=5)
    ttk.Button(btns, text="Monthly Chart", command=chart).pack(side="left", padx=5)

    refresh()
    dash.mainloop()

# ---------------- START APP ----------------
dashboard()
conn.close()
